CASTEL Jeremy
INFO 2

Compile :
=========

g++ main.cpp -o main.exe

Execute :
=========

Give the path to the file as a main parameter

	./main.exe <path to file>/20.in1


or Give the path to the file in the program

	./main.exe
	Saisir le nom de votre fichier : <path to file>/20.in1
